function testFn() {

const value1 = wid.value;

const wid = document.getElementById("wid");
wid.style.width = wid.value;

const hei = document.getElementById("hei");
hei.style.height = hei.value;

const fs = document.getElementById("fs");
fs.style.fontSize = fs.value;

const fc = document.getElementById("fc");
fc.style.fontcolor = fc.value;

const bgColor = document.querySelector("#bgcolor");
const box = document.querySelector("#box");

bgColor.addEventListener("keyup", function() {

if(e,key == "Enter"){
    box.style.backgroundColor = bgColor.value;
}
});

const box2 = document.querySelector("#box")

const value2 = box2.value;

innerHTML.



inner

}